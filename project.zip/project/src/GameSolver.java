import java.util.*;
import java.util.Queue;
import java.util.Stack;

public class GameSolver {
    Game game;
    protected HashMap<String, Board> boardConfigsExplored = new HashMap<>();
    protected HashMap<String, Board> isVisited = new HashMap<>();//记录已被访问的棋盘
    static int sp = -1;  //最终结果shortest path，用于存最短路径的长度。如果无路径，返回-1
    int[][] matrix;
    int layer1 = 0;
    int layer2 = 0;
    int layer3 = 0;
    int times  = 0;
    int difference=0;
    int plan1=0;

    public void solve(Game game) {
//        已经存在过的棋盘状态放入哈希表里
        this.game = game;
        matrix = endMatrix(game.initialBoard);
        bfs(game.initialBoard);
    }

    //判定该棋盘是否进过队
    static class node{
        Board currentBoard;
        node parent = null;
        int step;//用于存放起点到当前棋盘的最少步数（即层数）

        node(Board currentBoard, int step){
            this.currentBoard = currentBoard;
            this.step = step;
        }
    }

    public void bfs(Board currentBoard) {
        boardConfigsExplored.put(currentBoard.hashString, currentBoard);
        Queue<node> q = new LinkedList<>();
        ArrayList<int[][]> distance = new ArrayList<>(); // 最短路径中matrix的arraylist数组
        Stack<node> path = new Stack<>(); //用于记录最短路径上的结点
        q.add(new node(currentBoard, 0));
        while (!q.isEmpty()) {
            node temp = q.poll();
            boolean flag = true;
            //如果该棋盘为终点
            for (int i = 0; i < currentBoard.matrix.length; i++) {
                for (int j = 0; j < currentBoard.matrix[i].length; j++) {
                    if (temp.currentBoard.matrix[i][j] != matrix[i][j]) {
                        flag = false;
                        break;
                    }
                }
            }
            if (flag) {//找到最终结点
                sp = temp.step;
                path.push(temp);
                while (temp.parent != null) {
                    path.push(temp.parent);
                    temp = temp.parent;
                }
                break;
            }
            //不是终点
//            if(temp.step >= 35){
//                //System.out.println(Arrays.deepToString(temp.currentBoard.matrix));
//                /*while (q.size() > 1){
//                    node a = q.poll();
//                    node b = q.poll();
//                    if (different(a.currentBoard.matrix) < different(b.currentBoard.matrix) && different(a.currentBoard.matrix) < different(currentBoard.matrix)){
//                        q.offer(a);
//                        System.out.println(different(a.currentBoard.matrix));
//                        if (different(a.currentBoard.matrix) == 36){
//                            for (int i = 0; i < a.currentBoard.matrix.length; i++){
//                                for (int j = 0; j < a.currentBoard.matrix[0].length; j++){
//                                    System.out.print(a.currentBoard.matrix[i][j] + "  ");
//                                }
//                                System.out.println();
//                            }
//                            System.out.println();
//                        }
//                    }else if (different(b.currentBoard.matrix) < different(a.currentBoard.matrix) && different(b.currentBoard.matrix) < different(currentBoard.matrix)){
//                        q.offer(b);
//                        System.out.println(different(b.currentBoard.matrix));
//                        if (different(b.currentBoard.matrix) == 36){
//                            for (int i = 0; i < b.currentBoard.matrix.length; i++){
//                                for (int j = 0; j < b.currentBoard.matrix[0].length; j++){
//                                    System.out.print(b.currentBoard.matrix[i][j] + "  ");
//                                }
//                                System.out.println();
//                            }
//                            System.out.println();
//                        }
//                    }
//                }*/
//                if (dfs(temp)) { //当前结点能在深搜中找到最终节点
//                    break;
//                }
//            }
            else{
                for(int i = 0 ; i < currentBoard.blocks.length; i++) {
                    if (temp.currentBoard.blocks[i].blockfield.blockType != BlockType.BLANK){
                        ArrayList<Board> next = Next(temp.currentBoard, temp.currentBoard.blocks[i], temp.currentBoard.BlockNumber, currentBoard.num, currentBoard.type);
                        if (next.size() == 0) continue;
                        for (int j = 0; j < next.size(); j++){
                            //如果第一行相等，是新的棋盘
                            if (next.get(j).isNewBoard && Arrays.toString(next.get(j).matrix[0]).equals(Arrays.toString(this.matrix[0])) && layer1 == 0){
                                layer1++;
                                q.clear();
                                node newNode = new node(next.get(j),temp.step + 1);
                                q.offer(newNode);
                                newNode.parent = temp;
                                i = currentBoard.blocks.length;
//                                for (int m = 0; m < temp.currentBoard.matrix.length; m++){
//                                    for (int n = 0; n < temp.currentBoard.matrix[0].length; n++){
//                                        System.out.print(next.get(j).matrix[m][n] + "  ");
//                                    }
//                                    System.out.println();
//                                }
//                                System.out.println();
                                break;
                            }
                            if (currentBoard.row > 3 && next.get(j).isNewBoard && Arrays.toString(next.get(j).matrix[0]).equals(Arrays.toString(this.matrix[0])) && Arrays.toString(next.get(j).matrix[1]).equals(Arrays.toString(this.matrix[1])) && layer2 == 0){
                                layer2++;
                                q.clear();
                                node newNode = new node(next.get(j),temp.step + 1);
                                q.offer(newNode);
                                newNode.parent = temp;
                                i = currentBoard.blocks.length;
//                                for (int m = 0; m < temp.currentBoard.matrix.length; m++){
//                                    for (int n = 0; n < temp.currentBoard.matrix[0].length; n++){
//                                        System.out.print(next.get(j).matrix[m][n] + "  ");
//                                    }
//                                    System.out.println();
//                                }
//                                System.out.println();
                                break;
                            }
                            if (currentBoard.row > 4 && next.get(j).isNewBoard && Arrays.toString(next.get(j).matrix[0]).equals(Arrays.toString(this.matrix[0])) && Arrays.toString(next.get(j).matrix[1]).equals(Arrays.toString(this.matrix[1])) && Arrays.toString(next.get(j).matrix[2]).equals(Arrays.toString(this.matrix[2])) && layer3 == 0){
                                layer3++;
                                q.clear();
                                node newNode = new node(next.get(j),temp.step + 1);
                                q.offer(newNode);
                                newNode.parent = temp;
                                i = currentBoard.blocks.length;
//                                for (int m = 0; m < temp.currentBoard.matrix.length; m++){
//                                    for (int n = 0; n < temp.currentBoard.matrix[0].length; n++){
//                                        System.out.print(next.get(j).matrix[m][n] + "  ");
//                                    }
//                                    System.out.println();
//                                }
//                                System.out.println();
                                break;
                            }
                            if (different1(next.get(j).matrix) == 0 && next.get(j).isNewBoard && layer1 == 0){
                                node newNode = new node(next.get(j),temp.step + 1);
                                q.offer(newNode);
                                newNode.parent = temp;
//                                for (int m = 0; m < next.get(j).matrix.length; m++){
//                                    for (int n = 0; n < next.get(j).matrix[0].length; n++){
//                                        System.out.print(next.get(j).matrix[m][n] + "  ");
//                                    }
//                                    System.out.println();
//                                }
//                                System.out.println();
                            }
                            if (layer1 == 1 && layer2 == 0 && next.get(j).isNewBoard && Arrays.toString(next.get(j).matrix[0]).equals(Arrays.toString(this.matrix[0]))){
                                node newNode = new node(next.get(j),temp.step + 1);
                                q.offer(newNode);
                                newNode.parent = temp;
//                                for (int m = 0; m < next.get(j).matrix.length; m++){
//                                    for (int n = 0; n < next.get(j).matrix[0].length; n++){
//                                        System.out.print(next.get(j).matrix[m][n] + "  ");
//                                    }
//                                    System.out.println();
//                                }
//                                System.out.println();
                            }else if (layer2 == 1 && layer3 == 0 && next.get(j).isNewBoard && Arrays.toString(next.get(j).matrix[0]).equals(Arrays.toString(this.matrix[0])) && Arrays.toString(next.get(j).matrix[1]).equals(Arrays.toString(this.matrix[1]))){
                                node newNode = new node(next.get(j),temp.step + 1);
                                q.offer(newNode);
                                newNode.parent = temp;
//                                for (int m = 0; m < next.get(j).matrix.length; m++){
//                                    for (int n = 0; n < next.get(j).matrix[0].length; n++){
//                                        System.out.print(next.get(j).matrix[m][n] + "  ");
//                                    }
//                                    System.out.println();
//                                }
//                                System.out.println();
                            }else if (layer1 == 0  && plan1 == 0 && next.get(j).isNewBoard){
                                node newNode = new node(next.get(j),temp.step + 1);
                                q.offer(newNode);
                                newNode.parent = temp;
                            }else if (layer3 == 1 && next.get(j).isNewBoard && Arrays.toString(next.get(j).matrix[0]).equals(Arrays.toString(this.matrix[0])) && Arrays.toString(next.get(j).matrix[1]).equals(Arrays.toString(this.matrix[1])) && Arrays.toString(next.get(j).matrix[2]).equals(Arrays.toString(this.matrix[2]))){
                                node newNode = new node(next.get(j),temp.step + 1);
                                q.offer(newNode);
                                newNode.parent = temp;
//                                for (int m = 0; m < next.get(j).matrix.length; m++){
//                                    for (int n = 0; n < next.get(j).matrix[0].length; n++){
//                                        System.out.print(next.get(j).matrix[m][n] + "  ");
//                                    }
//                                    System.out.println();
//                                }
//                                System.out.println();
                            }
                        }
                    }
                }

            }
        }
        if (sp == -1) {
            System.out.println("No");
        } else {
            System.out.println("Yes");
            System.out.println(sp);
            path.pop();
            while (!path.isEmpty()) {
                node a = path.pop();
                distance.add(a.currentBoard.matrix);
                System.out.println(a.currentBoard.everyStep);
            }
        }
        this.game.distance = distance;
    }
//    Stack<node> s = new Stack<>();
//    public boolean dfs(node rootNode){
//        isVisited.put(rootNode.currentBoard.hashString,rootNode.currentBoard);
//        s.push(rootNode);
//        while(!s.isEmpty()){
//            node cur = s.peek();
//            boolean flag=true;
//            //如果该棋盘为终点
//            for(int i = 0 ; i < cur.currentBoard.matrix.length ; i ++){
//                for(int j = 0 ; j < cur.currentBoard.matrix[i].length ; j ++){
//                    if(cur.currentBoard.matrix[i][j] != matrix[i][j]){
//                        flag = false;
//                        break;
//                    }
//                }
//            }
//            if(flag){
//                //找到最终结点
//                //sp = cur.step;
//                sp = cur.step;
//                s.clear();
//                return true;
//            }
//            //不是终点
//            Queue<Board> next = new LinkedList<>(); //当前结点的所有下一步可行解
//            for(int i = 0 ; i < cur.currentBoard.blocks.length; i++) {
//                if (cur.currentBoard.blocks[i].blockfield.blockType != BlockType.BLANK){
//                    ArrayList<Board> next1 = newNext(cur.currentBoard, cur.currentBoard.blocks[i], cur.currentBoard.BlockNumber, cur.currentBoard.num, cur.currentBoard.type);
//                    for (Board board : next1) {
//                        if (!isVisited.containsKey(board.hashString)){
//                            next.add(board);
//                        }
//                    }
//                }
//            }
//            if (next.size() == 0){
//                s.pop();
//                if(s.isEmpty()){ //当前根节点后没有可行解，退出回到广搜拿到下一个根节点
//                    return false;
//                }else{
//                    dfs(s.pop());
//                }
//            }else {
//                Board newBoard = next.poll();
//                node newNode = new node(newBoard, cur.step+1);
//                //isVisited.put(newBoard.hashString,newBoard);
//                //s.push(newNode);
//                newNode.parent = cur;
//                System.out.println(isVisited.size());
//                dfs(newNode);
//            }
//        }
//        return false;
//    }
//
    private ArrayList<Board> newNext(Board currentBoard, Block oldBlock, int BlockNumber, int[] num, String[] type) {
        ArrayList<Board> arrayList = new ArrayList<>();
        for (MoveType moveType : MoveType.values()) {
            if (!currentBoard.isValidMove(oldBlock,moveType)) continue;
            int[][] newMatrix = getNextMatrix(currentBoard,oldBlock,moveType);
            Board board = new Board(newMatrix);
            board.row = newMatrix.length;
            board.column = newMatrix[0].length;
            board.num = num;
            board.type = type;
            board.everyStep = oldBlock.blockfield.number + " " + moveType;
            board.BlockNumber = BlockNumber;
            board.blocks = new Block[BlockNumber];
            int k = 0;
            ArrayList<Integer> arrayList1 = new ArrayList<>();
            for (int i = 0; i < board.column; i++){
                for (int j = 0; j < board.row; j++){
                    if (k < BlockNumber){
                        if (DrawPanel.contains(num,board.matrix[j][i]) >= 0){
                            switch (type[DrawPanel.contains(num, board.matrix[j][i])]) {
                                case "1*2" -> {
                                    board.blocks[k] = new Block(new Blockfield(BlockType.HORIZONTAL, board.matrix[j][i]), i, j);
                                    arrayList1.add(board.matrix[j][i + 1]);
                                }
                                case "2*1" -> {
                                    board.blocks[k] = new Block(new Blockfield(BlockType.VERTICAL, board.matrix[j][i]), i, j);
                                    arrayList1.add(board.matrix[j + 1][i]);
                                }
                                case "2*2" -> {
                                    board.blocks[k] = new Block(new Blockfield(BlockType.SQUARE, board.matrix[j][i]), i, j);
                                    arrayList1.add(board.matrix[j][i + 1]);
                                    arrayList1.add(board.matrix[j + 1][i]);
                                    arrayList1.add(board.matrix[j + 1][i + 1]);
                                }
                            }
//                            board.blocks[k].hashString = board.blocks[k].hashString();
//                            board.blocks[k].hashCode = board.blocks[k].hashCode();
                            k++;
                        }else {
                            if (board.matrix[j][i] == 0){
                                board.blocks[k] = new Block(new Blockfield(BlockType.BLANK, 0), i, j);
//                                board.blocks[k].hashString = board.blocks[k].hashString();
//                                board.blocks[k].hashCode = board.blocks[k].hashCode();
                                k++;
                            }else if (!arrayList1.contains(board.matrix[j][i])){
                                board.blocks[k] = new Block(new Blockfield(BlockType.SINGLE, board.matrix[j][i]), i, j);
//                                board.blocks[k].hashString = board.blocks[k].hashString();
//                                board.blocks[k].hashCode = board.blocks[k].hashCode();
                                k++;
                            }
                        }
                    }
                }
            }
            board.hashString = board.hashString();
//            board.hashCode = board.hashCode();
            arrayList.add(board);
        }
        return arrayList;
    }



//    public void bfs(Board currentBoard){
//        boardConfigsExplored.put(currentBoard.hashString,currentBoard);
//        currentBoard.finddifference(matrix);
//        Queue<node> q = new LinkedList<>();
//        ArrayList<int[][]> distance = new ArrayList<>(); // 最短路径中matrix的arraylist数组
//        Stack<node> path = new Stack<>(); //用于记录最短路径上的结点
//        q.add(new node(currentBoard,0));
//
//        while(!q.isEmpty()){
//            node temp = q.poll();
//            boolean flag=true;
//            //如果该棋盘为终点
//            for(int i = 0 ; i < currentBoard.matrix.length ; i ++){
//                for(int j = 0 ; j < currentBoard.matrix[i].length ; j ++){
//                    if(temp.currentBoard.matrix[i][j] != matrix[i][j]){
//                        flag = false;
//                        break;
//                    }
//                }
//            }
//            if(flag){//找到最终结点
//                sp = temp.step;
//                path.push(temp);
//                while(temp.parent != null){
//                    path.push(temp.parent);
//                    temp = temp.parent;
//                }
//                break;
//            }
//            //不是终点
//            b:for(int i = 0 ; i < currentBoard.blocks.length; i++) {
//                if (temp.currentBoard.blocks[i].blockfield.blockType != BlockType.BLANK){
//                    ArrayList<Board> next = Next(temp.currentBoard, temp.currentBoard.blocks[i], temp.currentBoard.BlockNumber, currentBoard.num, currentBoard.type);
//                    if (next.size() == 0) continue;
//                    a:for (int j = 0; j < next.size(); j++){
//                        next.get(j).finddifference(matrix);
//                        if (temp.step>=20&&next.get(j).isNewBoard &&next.get(j).findpartdifference(matrix)==0){
//                            node newNode = new node(next.get(j),temp.step + 1);
//                            System.out.println(temp.step);
//                            System.out.println(newNode.currentBoard.findpartdifference(matrix));
//                            System.out.println("快好啦");
//                            q.offer(newNode);
//                            newNode.parent = temp;
//                            break ;
//                        }
//                        if (next.get(j).isNewBoard && Arrays.toString(next.get(j).matrix[0]).equals(Arrays.toString(this.matrix[0])) && layer == 0){
//                            layer++;
//                            q.clear();
//                            node newNode = new node(next.get(j),temp.step + 1);
//                            q.offer(newNode);
//                            newNode.parent = temp;
//                            i = currentBoard.blocks.length;
//                            break ;
//                        }
////                        System.out.println(next.get(j).difference);
////                        System.out.println(temp.currentBoard.difference);
//                        if(temp.step>=12&&temp.step<=15){
////                            System.out.println(game.initialBoard.difference);
//                            if (next.get(j).isNewBoard&&next.get(j).difference<game.initialBoard.difference&&next.get(j).difference<temp.currentBoard.difference+2){
//                                node newNode = new node(next.get(j),temp.step + 1);
//                                System.out.println(temp.step);
//                                System.out.println(newNode.currentBoard.difference);
//                                System.out.println("--");
//                                q.offer(newNode);
//                                newNode.parent = temp;
//                            }
//                            break;
//                        }
//                        if(temp.step>15&&temp.step<=35){
////                            System.out.println(game.initialBoard.difference);
//                            if (next.get(j).isNewBoard&&next.get(j).difference<=game.initialBoard.difference/10*9&&next.get(j).difference<temp.currentBoard.difference+1){
//                                node newNode = new node(next.get(j),temp.step + 1);
//                                System.out.println(temp.step);
//                                System.out.println(newNode.currentBoard.difference);
//                                System.out.println("-----");
//                                q.offer(newNode);
//                                newNode.parent = temp;
//                            }
//                            break;
//                        }
//                        if(temp.step>35&&temp.step<=80){
////                            System.out.println(game.initialBoard.difference);
//                            if (next.get(j).isNewBoard&&next.get(j).difference<game.initialBoard.difference){
//                                node newNode = new node(next.get(j),temp.step + 1);
//                                System.out.println(temp.step);
//                                System.out.println(newNode.currentBoard.difference);
//                                System.out.println("-----");
//                                q.offer(newNode);
//                                newNode.parent = temp;
//                            }
//                            break ;
//                        }
//                        if(temp.step>80&&temp.step<=100){
////                            System.out.println(game.initialBoard.difference);
//                            if (next.get(j).isNewBoard&&next.get(j).difference<=game.initialBoard.difference/4*3){
//                                node newNode = new node(next.get(j),temp.step + 1);
//                                System.out.println(temp.step);
//                                System.out.println(newNode.currentBoard.difference);
//                                System.out.println("-----");
//                                q.offer(newNode);
//                                newNode.parent = temp;
//                            }
//                            break ;
//                        }
//                        if(temp.step>100){
////                            System.out.println(game.initialBoard.difference);
//                            if (next.get(j).isNewBoard){
//                                node newNode = new node(next.get(j),temp.step + 1);
//                                System.out.println(temp.step);
//                                System.out.println(newNode.currentBoard.difference);
//                                System.out.println("-----");
//                                q.offer(newNode);
//                                newNode.parent = temp;
//                            }
//                            break ;
//                        }
////                        if(temp.step>85&&temp.step<=100){
//////                            System.out.println(game.initialBoard.difference);
////                            if (next.get(j).isNewBoard&&next.get(j).difference<=game.initialBoard.difference-15){
////                                node newNode = new node(next.get(j),temp.step + 1);
////                                System.out.println(temp.step);
////                                System.out.println(newNode.currentBoard.difference);
////                                System.out.println("-----");
////                                q.offer(newNode);
////                                newNode.parent = temp;
////                            }
////                            break a;
////                        }
//                        if (next.get(j).isNewBoard){
//                            node newNode = new node(next.get(j),temp.step + 1);
//                            q.offer(newNode);
//                            newNode.parent = temp;
//                        }
//                    }
//                }
//            }
//        }
//        if(sp == -1){
//            System.out.println("No");
//        }else{
//            System.out.println("Yes");
//            System.out.println(sp);
//            path.pop();
//            while(!path.isEmpty()){
//                node a = path.pop();
//                distance.add(a.currentBoard.matrix);
//                System.out.println(a.currentBoard.everyStep);
//            }
//        }
//        this.game.distance=distance;
//    }
//public void dfs(node node){
//    boardConfigsExplored.put(node.currentBoard.hashString, node.currentBoard);
//    Stack<node> stack = new Stack<>();
//    boolean flag = false;
//    for(int i = 0 ; i < node.currentBoard.blocks.length; i++) {
//        if (node.currentBoard.blocks[i].blockfield.blockType != BlockType.BLANK){
//            ArrayList<Board> next = Next(node.currentBoard, node.currentBoard.blocks[i], node.currentBoard.BlockNumber, node.currentBoard.num, node.currentBoard.type);
//            if (next.size() == 0) continue;
//            for (int j = 0; j < next.size(); j++){
//                if (different(next.get(j).matrix) == 0){ //如果是终点
//                    node = node.parent;
//                    flag = true;
//                    i = node.currentBoard.blocks.length;
//                    break;
//                }
//                if (next.get(j).isNewBoard){
//                    node newNode = new node(next.get(j),node.step + 1);
//                    newNode.parent = node;
//                    dfs(newNode);
//                }
//            }
//        }
//    }
//    if (flag) {
//        System.out.println("Yes");
//    }else {
//        System.out.println("No");
//    }
//}
//
//    public void bfs(Board currentBoard){
//        boardConfigsExplored.put(currentBoard.hashString,currentBoard);
//        Queue<node> q = new LinkedList<>();
//        ArrayList<int[][]> distance = new ArrayList<>(); // 最短路径中matrix的arraylist数组
//        Stack<node> path = new Stack<>(); //用于记录最短路径上的结点
//        q.add(new node(currentBoard,0));
//
//        while(!q.isEmpty()){
//            node temp = q.poll();
//            if(different(temp.currentBoard.matrix) == 0){//找到最终结点
//                sp = temp.step;
//                path.push(temp);
//                while(temp.parent != null){
//                    path.push(temp.parent);
//                    temp = temp.parent;
//                }
//                break;
//            }
//           if (temp.step > 50){
//                dfs(temp);
//            }
//            //不是终点
//            /*if (temp.step == 5 || temp.step == 10 || temp.step == 15 || temp.step == 20  ){
//                while (q.size() > 3){
//                    node a = q.poll();
//                    node b = q.poll();
//                    node c = q.poll();
//                    node d = q.poll();
//                    if (different(a.currentBoard.matrix) > different(b.currentBoard.matrix) && different(a.currentBoard.matrix) > different(c.currentBoard.matrix) && different(a.currentBoard.matrix) > different(d.currentBoard.matrix)){
//                        q.offer(b);
//                        q.offer(c);
//                        q.offer(d);
//                    }
//                    if (different(b.currentBoard.matrix) > different(a.currentBoard.matrix) && different(b.currentBoard.matrix) > different(c.currentBoard.matrix) && different(b.currentBoard.matrix) > different(d.currentBoard.matrix)){
//                        q.offer(a);
//                        q.offer(c);
//                        q.offer(d);
//                    }
//                    if (different(c.currentBoard.matrix) > different(a.currentBoard.matrix) && different(c.currentBoard.matrix) > different(b.currentBoard.matrix) && different(c.currentBoard.matrix) > different(d.currentBoard.matrix)){
//                        q.offer(a);
//                        q.offer(b);
//                        q.offer(d);
//                    }
//                    if (different(d.currentBoard.matrix) > different(a.currentBoard.matrix) && different(d.currentBoard.matrix) > different(b.currentBoard.matrix) && different(d.currentBoard.matrix) > different(c.currentBoard.matrix)){
//                        q.offer(a);
//                        q.offer(b);
//                        q.offer(c);
//                    }
//                }
//                for (int i = 0; i < Objects.requireNonNull(q.peek()).currentBoard.matrix.length; i++){
//                    for (int j = 0; j < Objects.requireNonNull(q.peek()).currentBoard.matrix[0].length; j++){
//                        System.out.print(q.peek().currentBoard.matrix[i][j] + "  ");
//                    }
//                    System.out.println();
//                }
//                System.out.println();
//            }*/
//
//            /*if ((times + 10000) % 10000 == 0 ){
//                while (q.size() > 1){
//                    node a = q.poll();
//                    node b = q.poll();
//                    if (different(a.currentBoard.matrix) < different(b.currentBoard.matrix) && different(a.currentBoard.matrix) < different(currentBoard.matrix)){
//                        q.offer(a);
//                        System.out.println(different(a.currentBoard.matrix));
//                        if (different(a.currentBoard.matrix) == 36){
//                            for (int i = 0; i < a.currentBoard.matrix.length; i++){
//                                for (int j = 0; j < a.currentBoard.matrix[0].length; j++){
//                                    System.out.print(a.currentBoard.matrix[i][j] + "  ");
//                                }
//                                System.out.println();
//                            }
//                            System.out.println();
//                        }
//                    }else if (different(b.currentBoard.matrix) < different(a.currentBoard.matrix) && different(b.currentBoard.matrix) < different(currentBoard.matrix)){
//                        q.offer(b);
//                        System.out.println(different(b.currentBoard.matrix));
//                        if (different(b.currentBoard.matrix) == 36){
//                            for (int i = 0; i < b.currentBoard.matrix.length; i++){
//                                for (int j = 0; j < b.currentBoard.matrix[0].length; j++){
//                                    System.out.print(b.currentBoard.matrix[i][j] + "  ");
//                                }
//                                System.out.println();
//                            }
//                            System.out.println();
//                        }
//                    }
//                }
//            }*/
//            /*if (different1(temp.currentBoard.matrix) < difference1){
//                difference1 = different1(temp.currentBoard.matrix);
//                q.clear();
//                node newNode = new node(temp.currentBoard, temp.step);
//                q.offer(newNode);
//                for (int i = 0; i < temp.currentBoard.matrix.length; i++){
//                    for (int j = 0; j < temp.currentBoard.matrix[0].length; j++){
//                        System.out.print(temp.currentBoard.matrix[i][j] + "  ");
//                    }
//                    System.out.println();
//                }
//                System.out.println();
//            }*/
//            for(int i = 0 ; i < currentBoard.blocks.length; i++) {
//                if (temp.currentBoard.blocks[i].blockfield.blockType != BlockType.BLANK){
//                    ArrayList<Board> next = Next(temp.currentBoard, temp.currentBoard.blocks[i], temp.currentBoard.BlockNumber, currentBoard.num, currentBoard.type);
//                    if (next.size() == 0) continue;
//                    for (int j = 0; j < next.size(); j++){
//                        if (next.get(j).isNewBoard && Arrays.toString(next.get(j).matrix[0]).equals(Arrays.toString(this.matrix[0])) && layer1 == 0){
//                            layer1++;
//                            q.clear();
//                            node newNode = new node(next.get(j),temp.step + 1);
//                            q.offer(newNode);
//                            newNode.parent = temp;
//                            i = currentBoard.blocks.length;
//                            for (int m = 0; m < temp.currentBoard.matrix.length; m++){
//                                for (int n = 0; n < temp.currentBoard.matrix[0].length; n++){
//                                    System.out.print(next.get(j).matrix[m][n] + "  ");
//                                }
//                                System.out.println();
//                            }
//                            System.out.println();
//                            break;
//                        }
//                        if (currentBoard.row > 3 && next.get(j).isNewBoard && Arrays.toString(next.get(j).matrix[0]).equals(Arrays.toString(this.matrix[0])) && Arrays.toString(next.get(j).matrix[1]).equals(Arrays.toString(this.matrix[1])) && layer2 == 0){
//                            layer2++;
//                            q.clear();
//                            node newNode = new node(next.get(j),temp.step + 1);
//                            q.offer(newNode);
//                            newNode.parent = temp;
//                            i = currentBoard.blocks.length;
//                            for (int m = 0; m < temp.currentBoard.matrix.length; m++){
//                                for (int n = 0; n < temp.currentBoard.matrix[0].length; n++){
//                                    System.out.print(next.get(j).matrix[m][n] + "  ");
//                                }
//                                System.out.println();
//                            }
//                            System.out.println();
//                            break;
//                        }
//                        if (currentBoard.row > 4 && next.get(j).isNewBoard && Arrays.toString(next.get(j).matrix[0]).equals(Arrays.toString(this.matrix[0])) && Arrays.toString(next.get(j).matrix[1]).equals(Arrays.toString(this.matrix[1])) && Arrays.toString(next.get(j).matrix[2]).equals(Arrays.toString(this.matrix[2])) && layer3 == 0){
//                            layer3++;
//                            q.clear();
//                            node newNode = new node(next.get(j),temp.step + 1);
//                            q.offer(newNode);
//                            newNode.parent = temp;
//                            i = currentBoard.blocks.length;
//                            for (int m = 0; m < temp.currentBoard.matrix.length; m++){
//                                for (int n = 0; n < temp.currentBoard.matrix[0].length; n++){
//                                    System.out.print(next.get(j).matrix[m][n] + "  ");
//                                }
//                                System.out.println();
//                            }
//                            System.out.println();
//                            break;
//                        }
//                        if (layer1 == 1 && layer2 == 0 && next.get(j).isNewBoard && Arrays.toString(next.get(j).matrix[0]).equals(Arrays.toString(this.matrix[0]))){
//                            node newNode = new node(next.get(j),temp.step + 1);
//                            q.offer(newNode);
//                            newNode.parent = temp;
//                        }else if (layer2 == 1 && next.get(j).isNewBoard && Arrays.toString(next.get(j).matrix[0]).equals(Arrays.toString(this.matrix[0])) && Arrays.toString(next.get(j).matrix[1]).equals(Arrays.toString(this.matrix[1]))){
//                            node newNode = new node(next.get(j),temp.step + 1);
//                            q.offer(newNode);
//                            newNode.parent = temp;
//                        }else if (layer1 == 0 && next.get(j).isNewBoard){
//                            node newNode = new node(next.get(j),temp.step + 1);
//                            q.offer(newNode);
//                            newNode.parent = temp;
//                        }
//                    }
//                }
//            }
//            times++;
//        }
//        if(sp == -1){
//            System.out.println("No");
//            System.exit(0);
//        }else{
//            System.out.println("Yes");
//            System.out.println(sp);
//            path.pop();
//            while(!path.isEmpty()){
//                node a = path.pop();
//                distance.add(a.currentBoard.matrix);
//                System.out.println(a.currentBoard.everyStep);
//            }
//        }
//        this.game.distance = distance;
//    }
public boolean dfs(node rootNode) {
    isVisited.put(rootNode.currentBoard.hashString, rootNode.currentBoard);
    Stack<node> stack1 = new Stack<>();
    stack1.push(rootNode);
    while (!stack1.isEmpty()) {
        node cur = stack1.peek();
        //return true if cur is target;
        boolean flag = true;
        for (int i = 0; i < cur.currentBoard.matrix.length; i++) {
            for (int j = 0; j < cur.currentBoard.matrix[i].length; j++) {
                if (cur.currentBoard.matrix[i][j] != matrix[i][j]) {
                    flag = false;
                    break;
                }
            }
        }
        if (flag) {
            //找到最终结点
            //sp = cur.step;
            sp = cur.step;
            Stack<node> paths = new Stack<>();
            while(!stack1.isEmpty()){
                paths.push(stack1.pop());
            }
            while (!paths.isEmpty()) {
                node a = paths.pop();
                System.out.println(a.currentBoard.everyStep);
            }
            return true;
        }
        Queue<Board> next = new LinkedList<>(); //当前结点的所有下一步可行解
        for (int i = 0; i < cur.currentBoard.blocks.length; i++) {
            if (cur.currentBoard.blocks[i].blockfield.blockType != BlockType.BLANK) {
                ArrayList<Board> next1 = newNext(cur.currentBoard, cur.currentBoard.blocks[i], cur.currentBoard.BlockNumber, cur.currentBoard.num, cur.currentBoard.type);
                for (Board board : next1) {
                    if (!isVisited.containsKey(board.hashString)) {
                        next.add(board);
                    }
                }
            }
        }
        if(next.isEmpty()){
            stack1.pop();
        }else{
            for(Board board : next){
                if(!isVisited.containsKey(board.hashString)){
//                    System.out.println(cur.step);
                    node newNode = new node(board,cur.step+1);
                    stack1.push(newNode);
                    isVisited.put(board.hashString, board);
                    break ;//找到一个就退出循环
                }
            }
        }
    }
    return false;
}


    /*private Board getNextBoard(Board currentBoard, Block oldBlock) {
        MoveType[] moveTypes = MoveType.values(); // {U,D,L,R}
        for (MoveType moveType : moveTypes) {
            Block newBlock = calcNewBlock(currentBoard, oldBlock, moveType); // 如果有效，返回新的block.否则返回null
            if (newBlock == null) continue;//判断移动是否有效
            Board newBoard = new Board(currentBoard, oldBlock, newBlock); // 更新block[]数组
            newBoard.MAXXPOS = currentBoard.MAXXPOS;
            newBoard.MAXYPOS = currentBoard.MAXYPOS;
            newBoard.matrix = getNextMatrix(currentBoard, oldBlock, moveType);
            newBoard.hashString = newBoard.hashString();
            newBoard.hashCode = newBoard.hashCode();
            if (boardConfigsExplored.containsKey(newBoard.hashString)) {
                *//*newBoard = boardConfigsExplored.get(newBoard.hashString);*//*
                newBoard.isNewBoard = false;
            } else {
                boardConfigsExplored.put(newBoard.hashString, newBoard);
            }
            newBoard.everyStep = newBlock.blockfield.number +" "+ moveType;
            return newBoard;
        }
        return null;
    }*/

    /*private ArrayList<Board> NextBoard(Board currentBoard, Block oldBlock) {
        ArrayList<Board> arrayList = new ArrayList<>();
        MoveType[] moveTypes = MoveType.values(); // {U,D,L,R}
        for (MoveType moveType : moveTypes) {
            Block newBlock = calcNewBlock(currentBoard, oldBlock, moveType); // 如果有效，返回新的block.否则返回null
            if (newBlock == null) continue;//判断移动是否有效
            Board newBoard = new Board(currentBoard, oldBlock, newBlock); // 更新block[]数组
            newBoard.MAXXPOS = currentBoard.MAXXPOS;
            newBoard.MAXYPOS = currentBoard.MAXYPOS;
            newBoard.matrix = getNextMatrix(currentBoard, oldBlock, moveType);
            newBoard.hashString = newBoard.hashString();
            newBoard.hashCode = newBoard.hashCode();
            if (boardConfigsExplored.containsKey(newBoard.hashString)) {
                *//*newBoard = boardConfigsExplored.get(newBoard.hashString);*//*
                newBoard.isNewBoard = false;
            } else {
                boardConfigsExplored.put(newBoard.hashString, newBoard);

                for (int i = 0; i < newBoard.matrix.length; i++){
                    for (int j = 0; j < newBoard.matrix[0].length; j++){
                        System.out.print(newBoard.matrix[i][j] + "  ");
                    }
                    System.out.println();
                }
                System.out.println();

            }
            newBoard.everyStep = newBlock.blockfield.number +" "+ moveType;
            arrayList.add(newBoard);
        }
        return arrayList;
    }*/


    private ArrayList<Board> Next(Board currentBoard, Block oldBlock, int BlockNumber, int[] num, String[] type) {
        ArrayList<Board> arrayList = new ArrayList<>();
        for (MoveType moveType : MoveType.values()) {
            if (!currentBoard.isValidMove(oldBlock,moveType)) continue;
            int[][] newMatrix = getNextMatrix(currentBoard,oldBlock,moveType);
            Board board = new Board(newMatrix);
            board.row = newMatrix.length;
            board.column = newMatrix[0].length;
            board.num = num;
            board.type = type;
            board.everyStep = oldBlock.blockfield.number + " " + moveType;
            board.BlockNumber = BlockNumber;
            board.blocks = new Block[BlockNumber];
            int k = 0;
            ArrayList<Integer> arrayList1 = new ArrayList<>();
            for (int i = 0; i < board.column; i++){
                for (int j = 0; j < board.row; j++){
                    if (k < BlockNumber){
                        if (DrawPanel.contains(num,board.matrix[j][i]) >= 0){
                            switch (type[DrawPanel.contains(num, board.matrix[j][i])]) {
                                case "1*2" -> {
                                    board.blocks[k] = new Block(new Blockfield(BlockType.HORIZONTAL, board.matrix[j][i]), i, j);
                                    arrayList1.add(board.matrix[j][i + 1]);
                                }
                                case "2*1" -> {
                                    board.blocks[k] = new Block(new Blockfield(BlockType.VERTICAL, board.matrix[j][i]), i, j);
                                    arrayList1.add(board.matrix[j + 1][i]);
                                }
                                case "2*2" -> {
                                    board.blocks[k] = new Block(new Blockfield(BlockType.SQUARE, board.matrix[j][i]), i, j);
                                    arrayList1.add(board.matrix[j][i + 1]);
                                    arrayList1.add(board.matrix[j + 1][i]);
                                    arrayList1.add(board.matrix[j + 1][i + 1]);
                                }
                            }
//                            board.blocks[k].hashString = board.blocks[k].hashString();
//                            board.blocks[k].hashCode = board.blocks[k].hashCode();
                            k++;
                        }else {
                            if (board.matrix[j][i] == 0){
                                board.blocks[k] = new Block(new Blockfield(BlockType.BLANK, 0), i, j);
//                                board.blocks[k].hashString = board.blocks[k].hashString();
//                                board.blocks[k].hashCode = board.blocks[k].hashCode();
                                k++;
                            }else if (!arrayList1.contains(board.matrix[j][i])){
                                board.blocks[k] = new Block(new Blockfield(BlockType.SINGLE, board.matrix[j][i]), i, j);
//                                board.blocks[k].hashString = board.blocks[k].hashString();
//                                board.blocks[k].hashCode = board.blocks[k].hashCode();
                                k++;
                            }
                        }
                    }
                }
            }
            board.hashString = board.hashString();
//            board.hashCode = board.hashCode();
            if (boardConfigsExplored.containsKey(board.hashString)){
                board.isNewBoard = false;
            }else {
                boardConfigsExplored.put(board.hashString, board);
                /*for (int i = 0; i < board.matrix.length; i++){
                    for (int j = 0; j < board.matrix[0].length; j++){
                        System.out.print(board.matrix[i][j] + "  ");
                    }
                    System.out.println();
                }
                System.out.println();*/
                arrayList.add(board);
            }

            /*Block newBlock = calcNewBlock(currentBoard, oldBlock, moveType); // 如果有效，返回新的block.否则返回null
            if (newBlock == null) continue;//判断移动是否有效
            Board newBoard = new Board(currentBoard, oldBlock, newBlock); // 更新block[]数组
            newBoard.MAXXPOS = currentBoard.MAXXPOS;
            newBoard.MAXYPOS = currentBoard.MAXYPOS;
            newBoard.matrix = getNextMatrix(currentBoard, oldBlock, moveType);
            newBoard.hashString = newBoard.hashString();
            newBoard.hashCode = newBoard.hashCode();
            if (boardConfigsExplored.containsKey(newBoard.hashString)) {
                *//*newBoard = boardConfigsExplored.get(newBoard.hashString);*//*
                newBoard.isNewBoard = false;
            } else {
                boardConfigsExplored.put(newBoard.hashString, newBoard);

                for (int i = 0; i < newBoard.matrix.length; i++){
                    for (int j = 0; j < newBoard.matrix[0].length; j++){
                        System.out.print(newBoard.matrix[i][j] + "  ");
                    }
                    System.out.println();
                }
                System.out.println();

            }
            newBoard.everyStep = newBlock.blockfield.number +" "+ moveType;
            arrayList.add(newBoard);*/
        }
        return arrayList;
    }


    /*private static final int[][] moveStepsUP = {{0, -1}};
    private static final int[][] moveStepsDOWN = {{0, 1}};
    private static final int[][] moveStepsLEFT = {{-1, 0}};
    private static final int[][] moveStepsRIGHT = {{1, 0}};*/

    //根据当前棋盘的情况，当前的block以及移动方向，返回能移动到的block
    /*protected static Block calcNewBlock(Board oldBoard, Block oldBlock, MoveType moveType) {
        int[][] moveSteps = null;
        switch (moveType) {
            case U:
                moveSteps = moveStepsUP;
                break;
            case D:
                moveSteps = moveStepsDOWN;
                break;
            case L:
                moveSteps = moveStepsLEFT;
                break;
            case R:
                moveSteps = moveStepsRIGHT;
                break;
            default:
                assert false;
        }
        if (!oldBoard.isValidMove(oldBlock,moveType)) {
            return null;
        }
        return new Block(oldBlock, moveSteps[0][0], moveSteps[0][1]);
    }*/


    protected int[][] getNextMatrix(Board oldBoard, Block oldBlock, MoveType moveType) {
        int[][] matrix = new int[oldBoard.matrix.length][oldBoard.matrix[0].length];
        for (int i = 0; i < oldBoard.matrix.length; i++) {
            for (int j = 0; j < oldBoard.matrix[0].length; j++) {
                matrix[i][j] = oldBoard.matrix[i][j];
            }
        }
        for (int i = 0; i < oldBoard.matrix.length; i++) {
            for (int j = 0; j < oldBoard.matrix[0].length; j++) {
                if (oldBlock.blockfield.number == oldBoard.matrix[i][j]) {
                    if(moveType == MoveType.U) {
                        if (oldBlock.blockfield.blockType == BlockType.SINGLE){
                            matrix[i - 1][j] = oldBoard.matrix[i][j];
                            matrix[i][j] = 0;
                        }else if (oldBlock.blockfield.blockType == BlockType.HORIZONTAL){
                            matrix[i - 1][j] = oldBoard.matrix[i][j];
                            matrix[i - 1][j + 1] = oldBoard.matrix[i][j + 1];
                            matrix[i][j] = 0;
                            matrix[i][j + 1] = 0;
                        }else if (oldBlock.blockfield.blockType == BlockType.VERTICAL){
                            matrix[i - 1][j] = oldBoard.matrix[i][j];
                            matrix[i][j] = oldBoard.matrix[i + 1][j];
                            matrix[i + 1][j] = 0;
                        }else if (oldBlock.blockfield.blockType == BlockType.SQUARE){
                            matrix[i - 1][j] = oldBoard.matrix[i][j];
                            matrix[i - 1][j + 1] = oldBoard.matrix[i][j + 1];
                            matrix[i][j] = oldBoard.matrix[i + 1][j];
                            matrix[i][j + 1] = oldBoard.matrix[i + 1][j + 1];
                            matrix[i + 1][j] = 0;
                            matrix[i + 1][j + 1] = 0;
                        }
                    } else if(moveType==MoveType.D) {
                        if (oldBlock.blockfield.blockType == BlockType.SINGLE){
                            matrix[i + 1][j] = oldBoard.matrix[i][j];
                            matrix[i][j] = 0;
                        }else if (oldBlock.blockfield.blockType == BlockType.HORIZONTAL){
                            matrix[i + 1][j] = oldBoard.matrix[i][j];
                            matrix[i + 1][j + 1] = oldBoard.matrix[i][j + 1];
                            matrix[i][j] = 0;
                            matrix[i][j + 1] = 0;
                        }else if (oldBlock.blockfield.blockType == BlockType.VERTICAL){
                            matrix[i + 2][j] = oldBoard.matrix[i + 1][j];
                            matrix[i + 1][j] = oldBoard.matrix[i][j];
                            matrix[i][j] = 0;
                        }else if (oldBlock.blockfield.blockType == BlockType.SQUARE){
                            matrix[i + 2][j] = oldBoard.matrix[i + 1][j];
                            matrix[i + 2][j + 1] = oldBoard.matrix[i + 1][j + 1];
                            matrix[i + 1][j] = oldBoard.matrix[i][j];
                            matrix[i + 1][j + 1] = oldBoard.matrix[i][j + 1];
                            matrix[i][j] = 0;
                            matrix[i][j + 1] = 0;
                        }
                    } else if(moveType==MoveType.L) {
                        if (oldBlock.blockfield.blockType == BlockType.SINGLE){
                            matrix[i][j - 1] = oldBoard.matrix[i][j];
                            matrix[i][j] = 0;
                        }else if (oldBlock.blockfield.blockType == BlockType.HORIZONTAL){
                            matrix[i][j - 1] = oldBoard.matrix[i][j];
                            matrix[i][j] = oldBoard.matrix[i][j + 1];
                            matrix[i][j + 1] = 0;
                        }else if (oldBlock.blockfield.blockType == BlockType.VERTICAL){
                            matrix[i][j - 1] = oldBoard.matrix[i][j];
                            matrix[i + 1][j - 1] = oldBoard.matrix[i + 1][j];
                            matrix[i][j] = 0;
                            matrix[i + 1][j] = 0;
                        }else if (oldBlock.blockfield.blockType == BlockType.SQUARE){
                            matrix[i][j - 1] = oldBoard.matrix[i][j];
                            matrix[i + 1][j - 1] = oldBoard.matrix[i + 1][j];
                            matrix[i][j] = oldBoard.matrix[i][j + 1];
                            matrix[i + 1][j] = oldBoard.matrix[i + 1][j + 1];
                            matrix[i][j + 1] = 0;
                            matrix[i + 1][j + 1] = 0;
                        }
                    }else {
                        if (oldBlock.blockfield.blockType == BlockType.SINGLE){
                            matrix[i][j + 1] = oldBoard.matrix[i][j];
                            matrix[i][j] = 0;
                        }else if (oldBlock.blockfield.blockType == BlockType.HORIZONTAL){
                            matrix[i][j + 2] = oldBoard.matrix[i][j + 1];
                            matrix[i][j + 1] = oldBoard.matrix[i][j];
                            matrix[i][j] = 0;
                        }else if (oldBlock.blockfield.blockType == BlockType.VERTICAL){
                            matrix[i][j + 1] = oldBoard.matrix[i][j];
                            matrix[i + 1][j + 1] = oldBoard.matrix[i + 1][j];
                            matrix[i][j] = 0;
                            matrix[i + 1][j] = 0;
                        }else if (oldBlock.blockfield.blockType == BlockType.SQUARE){
                            matrix[i][j + 2] = oldBoard.matrix[i][j + 1];
                            matrix[i + 1][j + 2] = oldBoard.matrix[i + 1][j + 1];
                            matrix[i][j + 1] = oldBoard.matrix[i][j];
                            matrix[i + 1][j + 1] = oldBoard.matrix[i + 1][j];
                            matrix[i][j] = 0;
                            matrix[i + 1][j] = 0;
                        }
                    }
                }
            }
        }
        return matrix;
    }

    /*public Board endBlocks(){
        Board a = game.initialBoard; // 设 a 为初始棋盘
        int BlockNumber = a.row * a.column;
        for (int i = 0; i < a.type.length; i++){
            if (a.type[i].equals("1*2") || a.type[i].equals("2*1")){
                BlockNumber--;
            }else BlockNumber -= 3;
        }
        Block[] blocks = new Block[BlockNumber];
        int k = 0;
        ArrayList<Integer> arrayList = new ArrayList<>();
        for (int i = 0; i < a.column; i++){
            for (int j = 0; j < a.row; j++){
                if (k < BlockNumber){
                    if (DrawPanel.contains(a.num,endBoard().matrix[j][i]) >= 0){
                        switch (a.type[DrawPanel.contains(a.num, endBoard().matrix[j][i])]) {
                            case "1*2" -> {
                                blocks[k] = new Block(new Blockfield(BlockType.HORIZONTAL, endBoard().matrix[j][i]), i, j);
                                arrayList.add(endBoard().matrix[j][i + 1]);
                            }
                            case "2*1" -> {
                                blocks[k] = new Block(new Blockfield(BlockType.VERTICAL, endBoard().matrix[j][i]), i, j);
                                arrayList.add(endBoard().matrix[j + 1][i]);
                            }
                            case "2*2" -> {
                                blocks[k] = new Block(new Blockfield(BlockType.SQUARE, endBoard().matrix[j][i]), i, j);
                                arrayList.add(endBoard().matrix[j][i + 1]);
                                arrayList.add(endBoard().matrix[j + 1][i]);
                                arrayList.add(endBoard().matrix[j + 1][i + 1]);
                            }
                        }
                        blocks[k].hashString = blocks[k].hashString();
                        blocks[k].hashCode = blocks[k].hashCode();
                        k++;
                    }else {
                        if (endBoard().matrix[j][i] == 0){
                            blocks[k] = new Block(new Blockfield(BlockType.BLANK, 0), i, j);
                            blocks[k].hashString = blocks[k].hashString();
                            blocks[k].hashCode = blocks[k].hashCode();
                            k++;
                        }else if (!arrayList.contains(endBoard().matrix[j][i])){
                            blocks[k] = new Block(new Blockfield(BlockType.SINGLE, endBoard().matrix[j][i]), i, j);
                            blocks[k].hashString = blocks[k].hashString();
                            blocks[k].hashCode = blocks[k].hashCode();
                            k++;
                        }
                    }
                }
            }
        }
        return new Board(blocks, a.column, a.row);
    }*/
    public int[][] endMatrix(Board board){
        int[][] matrix = new int[board.row][board.column];
        for (int i = 0; i < board.row; i++){
            for (int j = 0; j < board.column; j++){
                if (i * board.column + j + 1 > board.max){
                    matrix[i][j] = 0;
                }else matrix[i][j] = i * board.column + j + 1;
            }
        }
        return matrix;
    }

    /*protected Board endBoard(){
        int size=game.initialBoard.MAXXPOS*game.initialBoard.MAXYPOS;
        ArrayList<Integer> endlist=new ArrayList<>();
        int[] solution = new int[size];
        int m=0;int n=0;
        for (int i = 0; i < game.initialBoard.MAXYPOS; i++) {
            for (int j = 0; j < game.initialBoard.MAXXPOS; j++) {
                if(game.initialBoard.matrix[i][j]!=0) {
                    endlist.add(game.initialBoard.matrix[i][j]);
                }
                m++;
            }
        }
        Collections.sort(endlist);
        for (int i = 0; i < endlist.size(); i++) {
            solution[i]=endlist.get(i);
        }
        int[][] matrix=new int[game.initialBoard.MAXYPOS][game.initialBoard.MAXXPOS];
        while (n<size) {
            for (int i=0; i < game.initialBoard.MAXYPOS; i++) {
                for (int j=0; j < game.initialBoard.MAXXPOS; j++) {
                    matrix[i][j] = solution[n];
                    n++;
                }
            }
        }
        return new Board(matrix);
    }*/
    public int different(int[][] matrix){
        difference = 0;
        for (int i = 0; i < matrix.length; i++){
            for (int j = 0; j < matrix[0].length; j++){
                difference += Math.abs(matrix[i][j] - this.matrix[i][j]);
            }
        }
        return difference;
    }
    public int different1(int[][] matrix){
        for (int i = 0; i < matrix.length; i++){
            for (int j = 0; j < matrix[0].length; j++){
                if (matrix[i][j] == 1) return i + j;
            }
        }
        return 0;
    }
}
